create function add_user(usn character varying, psw character varying) returns boolean
    language plpgsql
as
$$
begin
    if exists(select 1 from authuser where username = usn and password = psw) then
        return false;
    end if;
    insert into authuser(username, password) values (usn, psw);
    return true;
end
$$;

alter function add_user(varchar, varchar) owner to postgres;

